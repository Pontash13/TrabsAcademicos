
package clickersustentavel;

/*@Programa: Jogo no Estilo "Clicker" para APS do 3ºSemestre.   
*     @Tema: Sustentabilidade
*     @author's: Alysson Moreira Costa         (RA N4352J-9)
*                Augusto Benjamyn Leal Martins (RA N406BG-0) 
*                Fabricio Oliveira Dias        (RA D96323-6)
*                Gerson Prudencio dos Santos   (RA N43858-4)
*                Yury Rodrigues Shelkosvky     (RA F06216-3)
*                      
*     @Faculdade: UNIP / Campus Sorocaba 
*     @Curso: Ciência da Computação  
*     @Turma: CC3P17   
*     @Versao: sei lá 2.0
*     Concluído em: --/04/2020
*     Breve descricao: 
*         Este Jogo é um clicker  \o/  */

import Apresentacao.frmMenuPrincipal;


public class ClickerSustentavel
{

    public static void main(String[] args)
    {
        frmMenuPrincipal frmMenu = new frmMenuPrincipal(null, true);
        frmMenu.setVisible(true);
                
    }
}
