/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;


/**
 *
 * @author Yury
 */
public class Melhorias
{

    public Melhorias(Integer IndiceLista)
    {
        DefinirDescricao(IndiceLista);
    }
    
    private String descricao = "";
    
    private void DefinirDescricao(Integer IndiceLista)
    {
        if (IndiceLista == 0) descricao = "Descrição 1";
        if (IndiceLista == 1) descricao = "Descrição 2";
        if (IndiceLista == 2) descricao = "Descrição 3";
        if (IndiceLista == 3) descricao = "Descrição 4";
        if (IndiceLista == 4) descricao = "Descrição 5";
        if (IndiceLista == 5) descricao = "Descrição 6";
        if (IndiceLista == 6) descricao = "Descrição 7";
        if (IndiceLista == 7) descricao = "Descrição 8";
        if (IndiceLista == 8) descricao = "Descrição 9";
        if (IndiceLista == 9) descricao = "Descrição 10";
    }
    
    public void teste()
    {
        
    }

    public String getDescricao()
    {
        return descricao;
    }

    
    
    
    
    
}
