package Modelo;

public class MostrarDescricao
{

    public MostrarDescricao(int ItemN)
    {
        this.itemN = ItemN;
        DefinirDescricao();
    }
    
    private int itemN = 0;
    private String descricao = "";
    
    private void DefinirDescricao()
    {
        descricao = "";
        Itens itens = new Itens(0);
        if (this.itemN == 1)
        {
            this.descricao = "Separar Lixo em casa\n\n"
                    +"A preservação do meio ambiente começa em casa, separar o lixo\n"
                    +"corretamente permitirá com que materiais sejam economizados e\n"
                    +"tãnãnã...\n\n"
                    +"Valor para adicionar +1  Pessoa: "+ itens.precoatualItem1 + "\n"
                    +"Valor para adicionar +10 Pessoa: "+ (itens.precoatualItem1*10)+ "\n"
                    +"          Cada pessoa dá "+ itens.pontosItem1;
        }
        if (this.itemN == 2)
        {
            this.descricao = "Plantar uma árvores\n\n"
                    +"Por ano 12 Milhões de Hectares de árvores são cortadas\n"
                    +"Só na amazonia 1.8 bilhões.\n"
                    +"Ajude plantando uma.\n\n"
                    +"Valor para adicionar +1  Pessoa: "+ itens.precoatualItem2 + "\n"
                    +"Valor para adicionar +10  Pessoa: "+ (itens.precoatualItem2*10)+ "\n"
                    +"          Cada pessoa dá "+ itens.pontosItem2;
            
        }
        if (this.itemN == 3)
        {
            this.descricao = "Limpar o parque da cidade\n\n"
                    +"Fazendo sua parte vc deixa o ambiente melhor para todos\n"
                    +"Um lugar de lazer onde você poderá descansar com conciência limpa\n"
                    +"Ajude fazendo sua parte!\n"
                    +"Valor para adicionar +1  Pessoa: "+ itens.precoatualItem3 + "\n"
                    +"Valor para adicionar +10 Pessoa: "+ (itens.precoatualItem3*10)+ "\n"
                    +"          Cada pessoa dá "+ itens.pontosItem3;

        }
        if (this.itemN == 4)
        {
            this.descricao = "teste item4";
        }
        if (this.itemN == 5)
        {
            this.descricao = "teste item5";
        }
        if (this.itemN == 6)
        {
            this.descricao = "teste item6";
        }
        if (this.itemN == 7)
        {
            this.descricao = "teste\n item7";
        }
        if (this.itemN == 8)
        {
            this.descricao = "teste item8";
        }
        if (this.itemN == 9)
        {
            this.descricao = "teste item9";
        }
        if (this.itemN == 10)
        {
            this.descricao = "teste item10";
        }
    }
    
    public String GetDescricao()
    {
        
        return descricao;
    }
    
}
