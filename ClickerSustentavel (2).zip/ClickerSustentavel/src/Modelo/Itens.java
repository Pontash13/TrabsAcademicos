/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;


public class Itens
{

    public Itens()
    {
    }
        
    public Itens(Integer NovoJogo_1ou0)
    {
        definirValores(NovoJogo_1ou0);
    }
    
    public Itens(Integer NovoJogo_1ou0,Integer NumeroDoItem)
    {
        definirValores(NovoJogo_1ou0);
        definirPontos(NumeroDoItem);
    }
    
    private Double pontosGanhos = 0.0;
    
    //Item1 
    public String nomeItem1 = "Separar lixo em casa";
    public Double quantidadeItem1 = 1.0;
    public Double pontosItem1 = 1.0;
    public Double precoinicialItem1 = 15.0;
    public Double precoatualItem1 = 1.0;
    public long velocidadeInicialItem1 = 60;
    public long velocidadeAtualItem1 = 0;
    public Boolean automatico = true;

    //Item2
    public String nomeItem2 = "Plantar uma árvore";
    public Double quantidadeItem2 = 0.0;
    public Double pontosItem2 = 20.0;
    public Double precoinicialItem2 = 125.0;
    public Double precoatualItem2 = 0.0;
    public long velocidadeInicialItem2 = 150;
    public long velocidadeAtualItem2 = 0;
    
    //Item3
    public String nomeItem3 = "Limpar o parque da cidade";
    public Double quantidadeItem3 = 0.0;
    public Double pontosItem3 = 1.0;
    public Double precoinicialItem3 = 1000.0;
    public Double precoatualItem3 = 0.0;
    public long velocidadeInicialItem3 = 450;
    public long velocidadeAtualItem3 = 0;
    
    //Item4
    public String nomeItem4 = "Separar lixo em casa";
    public Double quantidadeItem4 = 0.0;
    public Double pontosItem4 = 1.0;
    public Double precoinicialItem4 = 5.0;
    public Double precoatualItem4 = 0.0;
    public long velocidadeInicialItem4 = 60;
    public long velocidadeAtualItem4 = 0;
    
    //Item5
    public String nomeItem5 = "Separar lixo em casa";
    public Double quantidadeItem5 = 0.0;
    public Double pontosItem5 = 1.0;
    public Double precoinicialItem5 = 5.0;
    public Double precoatualItem5 = 0.0;
    public long velocidadeInicialItem5 = 60;
    public long velocidadeAtualItem5 = 0;
    
    //Item6
    public String nomeItem6 = "Separar lixo em casa";
    public Double quantidadeItem6 = 0.0;
    public Double pontosItem6 = 1.0;
    public Double precoinicialItem6 = 5.0;
    public Double precoatualItem6 = 0.0;
    public long velocidadeInicialItem6 = 60;
    public long velocidadeAtualItem6 = 0;
    
    //Item7
    public String nomeItem7 = "Separar lixo em casa";
    public Double quantidadeItem7 = 0.0;
    public Double pontosItem7 = 1.0;
    public Double precoinicialItem7 = 5.0;
    public Double precoatualItem7 = 0.0;
    public long velocidadeInicialItem7 = 60;
    public long velocidadeAtualItem7 = 0;
    
    //Item8
    public String nomeItem8 = "Separar lixo em casa";
    public Double quantidadeItem8 = 0.0;
    public Double pontosItem8 = 1.0;
    public Double precoinicialItem8 = 5.0;
    public Double precoatualItem8 = 0.0;
    public long velocidadeInicialItem8 = 60;
    public long velocidadeAtualItem8 = 0;
    
    //Item9
    public String nomeItem9 = "Separar lixo em casa";
    public Double quantidadeItem9 = 0.0;
    public Double pontosItem9 = 1.0;
    public Double precoinicialItem9 = 5.0;
    public Double precoatualItem9 = 0.0;
    public long velocidadeInicialItem9 = 60;
    public long velocidadeAtualItem9 = 0;
    
    //Item10
    public String nomeItem10 = "Separar lixo em casa";
    public Double quantidadeItem10 = 0.0;
    public Double pontosItem10 = 1.0;
    public Double precoinicialItem10 = 5.0;
    public Double precoatualItem10 = 0.0;
    public long velocidadeInicialItem10 = 60;
    public long velocidadeAtualItem10 = 0;    
    
    
    private void definirValores(Integer NovoJogo_1ou0)
    {
        if(NovoJogo_1ou0 == 0)
        {
            quantidadeItem1 = new ControleJson(1).getQuantidadeItem();
            quantidadeItem2 = new ControleJson(2).getQuantidadeItem();
            quantidadeItem3 = new ControleJson(3).getQuantidadeItem();
            quantidadeItem4 = new ControleJson(4).getQuantidadeItem();
            quantidadeItem5 = new ControleJson(5).getQuantidadeItem();
            quantidadeItem6 = new ControleJson(6).getQuantidadeItem();
            quantidadeItem7 = new ControleJson(7).getQuantidadeItem();
            quantidadeItem8 = new ControleJson(8).getQuantidadeItem();
            quantidadeItem9 = new ControleJson(9).getQuantidadeItem();
            quantidadeItem10 = new ControleJson(10).getQuantidadeItem();
            
            precoatualItem1 = precoinicialItem1*quantidadeItem1;
            precoatualItem2 = precoinicialItem2*quantidadeItem2;
            precoatualItem3 = precoinicialItem3*quantidadeItem3;
            precoatualItem4 = precoinicialItem4*quantidadeItem4;
            precoatualItem5 = precoinicialItem5*quantidadeItem5;
            precoatualItem6 = precoinicialItem6*quantidadeItem6;
            precoatualItem7 = precoinicialItem7*quantidadeItem7;
            precoatualItem8 = precoinicialItem8*quantidadeItem8;
            precoatualItem9 = precoinicialItem9*quantidadeItem9;
            precoatualItem10 = precoinicialItem10*quantidadeItem10;
        }
        if (NovoJogo_1ou0 == 1)
        {
            new ControleJson(1, 1.0);
            new ControleJson(2, 0.0);
            new ControleJson(3, 0.0);
            new ControleJson(4, 0.0);
            new ControleJson(5, 0.0);
            new ControleJson(6, 0.0);
            new ControleJson(7, 0.0);
            new ControleJson(8, 0.0);
            new ControleJson(9, 0.0);
            new ControleJson(10, 0.0);
        }
        
        
        
        if(quantidadeItem1 != 0.0)
        {
            if(velocidadeInicialItem1/Math.round(quantidadeItem1) < 1.0) velocidadeAtualItem1 = 1;
            else velocidadeAtualItem1 = velocidadeInicialItem1/Math.round(quantidadeItem1);
        }
        if(quantidadeItem2 != 0.0)
        {
            if(velocidadeInicialItem2/Math.round(quantidadeItem2) < 1.0) velocidadeAtualItem2 = 1;
            else velocidadeAtualItem2 = velocidadeInicialItem2/Math.round(quantidadeItem2);
        }
        if(quantidadeItem3 != 0.0) 
        {
            if(velocidadeInicialItem3/Math.round(quantidadeItem3) < 1.0) velocidadeAtualItem3 = 1;
            else velocidadeAtualItem3 = velocidadeInicialItem3/Math.round(quantidadeItem3);
        }
        if(quantidadeItem4 != 0.0) 
        {
            if(velocidadeInicialItem4/Math.round(quantidadeItem4) < 1.0) velocidadeAtualItem4 = 1;
            else velocidadeAtualItem4 = velocidadeInicialItem4/Math.round(quantidadeItem4);
        }
        if(quantidadeItem5 != 0.0)
        {
            if(velocidadeInicialItem5/Math.round(quantidadeItem5) < 1.0) velocidadeAtualItem5 = 1;
            else velocidadeAtualItem5 = velocidadeInicialItem5/Math.round(quantidadeItem5);
        }
        
        if(quantidadeItem6 != 0.0) velocidadeAtualItem6 = velocidadeInicialItem6/Math.round(quantidadeItem6);
        if(quantidadeItem7 != 0.0) velocidadeAtualItem7 = velocidadeInicialItem7/Math.round(quantidadeItem7);
        if(quantidadeItem8 != 0.0) velocidadeAtualItem8 = velocidadeInicialItem8/Math.round(quantidadeItem8);
        if(quantidadeItem9 != 0.0) velocidadeAtualItem9 = velocidadeInicialItem9/Math.round(quantidadeItem9);
        if(quantidadeItem10 != 0.0) velocidadeAtualItem10 = velocidadeInicialItem10/Math.round(quantidadeItem10);
    }
    
    private void definirPontos(Integer NumeroDoItem)
    {
        if (NumeroDoItem == 1) pontosGanhos = pontosItem1*quantidadeItem1;
        if (NumeroDoItem == 2) pontosGanhos = pontosItem2*quantidadeItem2;
        if (NumeroDoItem == 3) pontosGanhos = pontosItem3*quantidadeItem3;
        if (NumeroDoItem == 4) pontosGanhos = pontosItem4*quantidadeItem4;
        if (NumeroDoItem == 5) pontosGanhos = pontosItem5*quantidadeItem5;
        if (NumeroDoItem == 6) pontosGanhos = pontosItem6*quantidadeItem6;
        if (NumeroDoItem == 7) pontosGanhos = pontosItem7*quantidadeItem7;
        if (NumeroDoItem == 8) pontosGanhos = pontosItem8*quantidadeItem8;
        if (NumeroDoItem == 9) pontosGanhos = pontosItem9*quantidadeItem9;
        if (NumeroDoItem == 10) pontosGanhos = pontosItem10*quantidadeItem10;
    }

    public Double getPontosGanhos()
    {
        return pontosGanhos;
    }
    
}

