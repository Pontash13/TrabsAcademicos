package Modelo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ControleJson 
{
    public ControleJson()
    {
        LerSave();
    }
    
    
    
    public ControleJson(Integer NumeroDoItem)
    {
        LerSave();
        DefinirItem(NumeroDoItem);
    }
    
    
    
    public ControleJson(Integer NumeroDoItem,Double NovoValor)
    {
        LerSave();
        DefinirItem(NumeroDoItem);
        AlterarQuantidade(item, NovoValor);
        EscreverJson();
    }
    
    
    
    public ControleJson(Double NovaQuantidadePontos)
    {
        LerSave();
        AlterarPontos(NovaQuantidadePontos);
        EscreverJson();
    }
    
    
    
    private JSONObject objetoJson;
    private String item = "";
    
    
    
    private void DefinirItem(Integer NumeroDoItem)
    {
        if(NumeroDoItem == 1) item = "1";
        if(NumeroDoItem == 2) item = "2";
        if(NumeroDoItem == 3) item = "3";
        if(NumeroDoItem == 4) item = "4";
        if(NumeroDoItem == 5) item = "5";
        if(NumeroDoItem == 6) item = "6";
        if(NumeroDoItem == 7) item = "7";
        if(NumeroDoItem == 8) item = "8";
        if(NumeroDoItem == 9) item = "9";
        if(NumeroDoItem == 10) item = "10";
    }
        
    
    
    private void LerSave()
    {
        //Instancia um interpretador de arquivo JSON
        JSONParser InterpretadorJson = new JSONParser();
        
        try {
            //Salva no objeto JSONObject o que o parse tratou do arquivo
            objetoJson = (JSONObject) InterpretadorJson.parse(new FileReader("Save.json"));
             
        } 
        //Trata as exceptions que podem ser lançadas no decorrer do processo
        catch(FileNotFoundException e)
        {
            e.printStackTrace();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        } 
        catch (ParseException e) 
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } 
    }
    
    
    
    private void AlterarQuantidade(String NumeroDoItem,Double NovoValor)
    {
        //Armazena dados em um Objeto JSON
        objetoJson.replace("quantidadeItem"+item, NovoValor.toString());
        
    }
    
    
    
    private void AlterarPontos(Double QuantidadePontos)
    {
        //Armazena dados em um Objeto JSON
        objetoJson.replace("quantidadePontos", QuantidadePontos.toString());
    }
    
    
    
    private void EscreverJson()
    {
        FileWriter writeFile = null;
        
        try{
            writeFile = new FileWriter("Save.json");
            //Escreve no arquivo conteudo do Objeto JSON
            writeFile.write(objetoJson.toJSONString());
            writeFile.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
    
    
    
    public Double getQuantidadeItem()
    {   
        return Double.parseDouble((String) objetoJson.get("quantidadeItem"+item));
    }
    
    
    
    public Double getQuantidadePontos()
    {
        return Double.parseDouble((String) objetoJson.get("quantidadePontos"));
    }

  
}
