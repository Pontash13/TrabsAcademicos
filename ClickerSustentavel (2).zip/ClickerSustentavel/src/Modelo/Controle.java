package Modelo;

public class Controle
{
    public Controle ()
    {
    }
    
    public Controle (javax.swing.JProgressBar BarraDoItem,Integer NumeroDoItem,javax.swing.JLabel LabelDosPontos)
    {
        RealizarItem realizaritem = new RealizarItem(BarraDoItem,NumeroDoItem,LabelDosPontos);
    }
    
    public Controle (Integer NumeroDoItem, javax.swing.JLabel LabelDosPontos)
    {
        Itens itens = new Itens(0, NumeroDoItem);
        PontosSustentabilidade pontos = new PontosSustentabilidade(0);
        pontos.addPontos(itens.getPontosGanhos());
        LabelDosPontos.setText(pontos.getPontosString());
    }
    
    public String DescricaoItem(Integer NumeroDoItem)
    {
        MostrarDescricao mostrardescricao = new MostrarDescricao(NumeroDoItem);
        return mostrardescricao.GetDescricao();
    }
    
}
