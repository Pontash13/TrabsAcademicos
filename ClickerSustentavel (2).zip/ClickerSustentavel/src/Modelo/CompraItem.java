package Modelo;

import javax.swing.JOptionPane;

/*        -----Para retirar futuramente------ 
 * Ao invéis de criar uma nova classe para comprar 10 itens, achei mais comodo
 * mandar o "complemento" no ato de apertar o botão e depois apenas multiplicar 
 * pelo preço e quantidade.
 */

public class CompraItem
{   
    public Double precoitem  = 0.0;
    public Double qtipontos  = 0.0;
    public Double qtipessoas = 0.0;
    public Double conta = 0.0;
    public int item = 0;
   
    
    public CompraItem(javax.swing.JLabel LabelQuantidadedeItens,
            javax.swing.JLabel LabelQuantidadedepontos, Integer Numerodoitem, Integer complemento)
    {
        LabelQuantidadedeItens.getText();
        item = Numerodoitem;
        Itens itens = new Itens(0, item);
        
        
        
        //Aqui indica o preço do item clicado
        if(Numerodoitem == 1 )precoitem = itens.precoatualItem1;
        if(Numerodoitem == 2 )precoitem = itens.precoatualItem2;
        if(Numerodoitem == 3 )precoitem = itens.precoatualItem3;
        if(Numerodoitem == 4 )precoitem = itens.precoatualItem4;
        if(Numerodoitem == 5 )precoitem = itens.precoatualItem5;
        if(Numerodoitem == 6 )precoitem = itens.precoatualItem6;
        if(Numerodoitem == 7 )precoitem = itens.precoatualItem7;
        if(Numerodoitem == 8 )precoitem = itens.precoatualItem8;
        if(Numerodoitem == 9 )precoitem = itens.precoatualItem9;
        if(Numerodoitem == 10)precoitem = itens.precoatualItem10;
        
        
        ValidarCompra(LabelQuantidadedeItens, LabelQuantidadedepontos, complemento);
      
    }        
    private void ValidarCompra(javax.swing.JLabel LabelQuantidadedeItens,
            javax.swing.JLabel LabelQuantidadedepontos, Integer complemento)
    {
        //passa os label's que estão nos parametros para duas variáveis
        qtipontos = Double.parseDouble(LabelQuantidadedepontos.getText());
        qtipessoas = Double.parseDouble(LabelQuantidadedeItens.getText());
        precoitem *= complemento;
        
        //multiplica o preco do item por dez ou um, depende do botão precionado
        if((precoitem) <= qtipontos)
        {
            qtipessoas += complemento;
            conta = qtipontos - precoitem;
            ControleJson cjson = new ControleJson(item,(qtipessoas));
            new ControleJson(conta);
            
            
            
            //istancía os valores nos labels
            LabelQuantidadedeItens.setText(qtipessoas.toString());
            LabelQuantidadedepontos.setText(conta.toString());
            
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Você não tem pontos suficientes");
        }
    }   
}