/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Yury
 */
public class PontosSustentabilidade
{
    public PontosSustentabilidade()
    {
        
    }
    
    
    public PontosSustentabilidade(Integer NovoJogo_1ou0)
    {
        definirPontos(NovoJogo_1ou0);
    }
    
    private Double pontos = 0.0;

    private void definirPontos(Integer NovoJogo_1ou0)
    {
        if(NovoJogo_1ou0 == 0)
        {
            this.pontos = new ControleJson().getQuantidadePontos();
        }
        if(NovoJogo_1ou0 == 1)
        {
            this.pontos = new ControleJson(0.0).getQuantidadePontos();
            SalvarPontos();
        }
    }
    
    public void addPontos(Double QtdDePontos)
    {
        this.pontos += QtdDePontos;
        SalvarPontos();
    }
    
    public void SalvarPontos()
    {
        new ControleJson(pontos);
    }
    
    public Double getPontos()
    {
        return pontos;
    }
        
    public String getPontosString()
    {
        return pontos.toString();
    }
}
